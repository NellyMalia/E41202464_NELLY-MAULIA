/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DynamicDispatch;

/**
 *
 * @author nelly maulia
 */
public class C extends A {
    void callthis(){
        System.out.println("Inside Class B's Method");
    }
}